<?php $this->load->view('siatex/_blocks/header') ?>

<section id="main_inner">
</section>

<?php $this->load->view('siatex/_blocks/footer') ?>