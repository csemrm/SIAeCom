</div>
 
<!--Body-->

<!--Footer-->
<div class="footer_bg">
    <div class="footer_tex">
        <div class="fore_box">
            <h5>Our menu</h5>
            <ol class="footnotes">
                <li>&raquo;  <span><a href="<?php echo site_url() ?>">Home</a></span></li>
                <li>&raquo;  <span><a href="<?php echo site_url('products'); ?>">Products</a></span></li>
                <li>&raquo; <span><a href="<?php echo site_url('services'); ?>">Services</a></span></li>
                <li>&raquo; <span><a href="<?php echo site_url('contact'); ?>">Contact us</a></span></li>
            </ol>                                       
        </div>
        <div class="fore_box">
            <h5>Head Office</h5>
            <ol class="footnotes">
                <li><span>Siatex Bangladesh Limited</span></li>
                <li> <span>House # 8, Road # 6, BLK "E"</span></li>
                <li><span>Niketon,Gulshan -1,Dhaka</span></li>
                <li> <span>Phone: (+880-2) 985-9720</span></li>
            </ol>     
        </div>
        <div class="fore_box">
            <h5>Sales Office </h5>
            <ol class="footnotes">
                <li><span>Siatex Bangladesh Limited</span></li>
                <li> <span>House # 8, Road # 6, BLK "E"</span></li>
                <li><span>Niketon,Gulshan -1,Dhaka</span></li>
                <li> <span>Phone: (+880-2) 985-9720</span></li>
            </ol>     
        </div>
        <div class="fore_box">
            <h5>Canada Sales Office </h5>
            <ol class="footnotes">
                <li> <span>APTEX Canada Limited</span></li>
                <li> <span>22 Hagley Road</span></li>
                <li> <span>Toronto, M1M 1S9</span></li>
                <li> <span>ON Canada</span></li>
            </ol>     
        </div>



    </div>
    <div class="copy_right">Copyright © 2013  Dutta Fashion. All rights reserved. 

        <span class="bottom_menu"><a href="contact">Contact Us </a> |     <a href="about">About Us</a></span>

    </div>

</div>
<!--Footer-->

</div>
<?php echo js('main,siatex/front/menu') . js($js); ?>
</body>
</html>



