<div id="content" style="width:595px; margin:auto;"><br>
    <table width="100%">
        <tr><td valign="bottom" align="left"><h1><br><br><?php // echo $web_info['com_name'];   ?></h1></td>
            <td style="font-size:13px; padding-bottom:10px;" align="right" valign="top">
                <br>
            </td></tr>
    </table>
    <div style="width:595px; border: 1px solid #666;">
        <?= $viewhtml1 ?>
    </div>    
</div>