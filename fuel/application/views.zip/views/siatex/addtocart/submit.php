<?php $this->load->view('siatex/_blocks/header') ?>

<section id="main_inner">
<?= $viewhtml1 ?>
</section>

<?php $this->load->view('siatex/_blocks/footer') ?>