<?php 
redirect($redirect_to);
?>