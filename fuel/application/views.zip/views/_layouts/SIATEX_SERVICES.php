<?php $this->load->view('siatex/_blocks/header') ?>

<section id="services">
    <aside id="services_left_box">
        <?php echo fuel_var('body'); ?>
    </aside>
    <aside id="services_right_box_one" class="services_right_box_one"> 
    </aside>
</section>

<?php $this->load->view('siatex/_blocks/footer') ?>