<?php $this->load->view('siatex/_blocks/header') ?>
	
	<section id="main_inner">
		<?php echo fuel_var('body', 'This is a default layout. To change this layout go to the ........ file.'); ?>
	</section>
	
<?php $this->load->view('siatex/_blocks/footer') ?>